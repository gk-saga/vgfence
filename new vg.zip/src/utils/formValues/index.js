
export const FORM_VALUES = {
  planFormValuesFromStore: {
    planName: "",
    planImage: "",
    description: "",
    duration: "",
    taxIds: "",
    amount: "",
    errorStatus: {
      planName: false,
      description: false,
      taxIds: false,
      duration: false,
      amount: false,
      planImage: false,
    },
  },
};
